#!/bin/bash
echo Hello $1. Today is $2.
