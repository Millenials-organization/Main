def call(body) {
    easyPipeline("master",body)
}