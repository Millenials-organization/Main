def call() {
  return "roxy-"+UUID.randomUUID().toString().substring(0,13)
}