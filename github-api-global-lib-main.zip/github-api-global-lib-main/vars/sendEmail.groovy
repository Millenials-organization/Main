def call(String to, String subject, String message) {
    echo "${to}"
    echo "${subject}"
    echo "${message}"
}